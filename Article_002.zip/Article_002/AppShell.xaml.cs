﻿namespace Article_002;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
